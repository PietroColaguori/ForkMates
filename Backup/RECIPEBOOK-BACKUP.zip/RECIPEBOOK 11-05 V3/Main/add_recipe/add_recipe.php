<?php
    if($_SERVER['REQUEST_METHOD'] != 'POST') {
        header("Location: /add_recipe/add_recipe.html ");        
    }
    include '../connectionDB.php';
?>      
        <?php
            session_start();

            if(isset($_POST['submit'])) {

                $title = $_POST['inputTitle'];
                $category = $_POST['inputCategory'];
                if(isset($_POST['inputDescription'])) {
                    $description = $_POST['inputDescription'];
                }
                else {
                    $description = NULL;
                }
                $ingredients = $_POST['inputIngredients'];
                $procedure = $_POST['inputProcedure'];
                $difficulty = $_POST['inputDifficulty'];
                $prepTime = $_POST['inputPrepTime'];
                $cookTime = $_POST['inputCookTime'];
                $numPeople = $_POST['inputNumPeople'];

                $alreadyPresent = 0;
                $searchQuery = "SELECT * FROM ricette WHERE titolo=$1 AND utente=$2";
                $searchResult = pg_query_params($dbconn, $searchQuery, array($title, $_SESSION['username']));
                if(pg_num_rows($searchResult) > 0) {
                    $alreadyPresent = 1;
                }

                if(!$alreadyPresent) {
                    $hasImage = 0;
                
                    if(isset($_FILES["inputPic0"]) && $_FILES["inputPic0"]["error"] == 0) {
                        $targetdir = '../recipes_pictures/';
                        $parsedTitle = str_replace(array(" ", "'"), "", $title);
                        $targetfile = $targetdir . $parsedTitle . $_SESSION['username'] . ".jpeg";
                        move_uploaded_file($_FILES["inputPic0"]["tmp_name"], $targetfile);
                        $hasImage = 1;
                    }

                    $query = "INSERT INTO ricette VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)";
                    $result = pg_query_params($dbconn, $query, array($title, $category, $description, $ingredients, $procedure, $_SESSION['username'], $difficulty, $prepTime, $cookTime, $numPeople, $hasImage));
                    
                    $query2 = "UPDATE utenti SET ricette = ricette + 1 WHERE username = $1";
                    $result2 = pg_query_params($dbconn, $query2, array($_SESSION['username']));

                    if($result) {
                        $id = $_SESSION['username'];
                        header('Location: ../profile/profile.php?param='.$id.'');
                    }
                    else { die("An error occurred!"); }
                }

                else {
                    echo "<script>alert('You already inserted a recipe with this name! Change it and try again.'); window.location.href='../add_recipe/add_recipe.html';</script>";
                }

                pg_close($dbconn);
            }
            else {
                echo "<script>alert('Fill in the form before submitting!'); window.location.href='../add_recipe/add_recipe.html';</script>";

            }
        ?>

