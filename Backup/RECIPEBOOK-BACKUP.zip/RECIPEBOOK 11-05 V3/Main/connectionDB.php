<?php
    $dbconn = pg_connect("host=localhost user=claudiocambone password=2551 port=5432 dbname=ForkMates");
?>