<!DOCTYPE html>

<?php
    include '../connectionDB.php';
?>
   <?php session_start(); 
        if($_SESSION['loggedIn'] == false) {
            header("Location: ../redirect.html");
            exit;
          }
        else{
            $id = $_SESSION['idpic'];
            $utente = $_SESSION['username'];
            switch($_POST['selezione']){
                case 1:
                    $query = "DELETE from utenti where idpic = $1";
                    $results = pg_query_params($dbconn,$query,array($id));
                    if($results){
                        pg_close($dbconn);
                        header("Location: ../logout.php");
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                    break;
                case 2:
                    $query = "DELETE from utenti where idpic = $1";
                    $results = pg_query_params($dbconn,$query,array($id));
                    if($results){
                        $query = "DELETE from ricette where utente = $1";
                        $results = pg_query_params($dbconn,$query,array($utente));
                        if($results){
                        pg_close($dbconn);
                        header("Location: ../logout.php");
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                    break;
                case 3:
                    $query = "DELETE from utenti where idpic = $1";
                    $results = pg_query_params($dbconn,$query,array($id));
                    if($results){
                        $query = "DELETE from recensioni where recensore = $1";
                        $results = pg_query_params($dbconn,$query,array($utente));
                        if($results){
                        pg_close($dbconn);
                        header("Location: ../logout.php");
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                    break;
                case 4:
                    $query = "DELETE from utenti where idpic = $1";
                    $results = pg_query_params($dbconn,$query,array($id));
                    if($results){
                        $query = "DELETE from ricette where utente = $1";
                        $results = pg_query_params($dbconn,$query,array($utente));
                        if($results){
                        $query = "DELETE from recensioni where recensore = $1";
                        $results = pg_query_params($dbconn,$query,array($utente));
                        if($results){
                        pg_close($dbconn);
                        header("Location: ../logout.php");
                        
                    }
                    else{
                        echo 'sbagliato';
                    }
                    }
                    else{
                        echo 'sbagliato';
                    }
                        
                    }
                    else{
                        echo 'sbagliato';
                    }


                
            }
        }