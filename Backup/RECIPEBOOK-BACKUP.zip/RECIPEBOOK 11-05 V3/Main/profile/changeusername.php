<!DOCTYPE html>
<title>Update Account</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width", initial-scale="1.0">        
    </head>
    <body>     
        <?php
            if($_SERVER['REQUEST_METHOD'] != 'POST') {
                header("Location: /login/login.html ");        
            }
            include '../connectionDB.php';
            $newname = $_POST['newname'];
            $username = $_POST['actualname'];
            $query ="UPDATE utenti
            SET username = '$newname'
            WHERE username = '$username'";
            $result = pg_query($dbconn, $query);
            if(!$result){
            echo'ERROR 0';
          }
          $query ="UPDATE ricette
            SET utente = '$newname'
            WHERE utente = '$username'";
            $result = pg_query($dbconn, $query);
            if(!$result){
                echo'ERROR 1';
            }
            $query ="UPDATE recensioni
            SET recensore = '$newname'
            WHERE recensore = '$username'";
            $result = pg_query($dbconn, $query);
            if(!$result){
                echo'ERROR 2';
            }
            $query ="UPDATE recensioni
            SET recensito = '$newname'
            WHERE recensito = '$username'";
            $result = pg_query($dbconn, $query);
            if(!$result){
                echo'ERROR 3';
            }
            pg_close($dbconn);
            header("Location: ../login/login.php");
            exit;
              ?>
    </body>
</html>
