<!DOCTYPE html>

<?php
    include '../connectionDB.php';
?>

<html>
    <head>
        <title>Profile</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- NAVBAR -->
        <link rel="stylesheet" href="../css/home_style.css">
        <!-- MODAL DIALOG -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <!-- PROFILE -->
        <!-- BOOTSTRAP -->
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.css"/>
        <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
        <script src="../bootstrap/js/bootstrap.bundle.js"></script>
        <!-- CARDS -->
        <link rel="stylesheet" href="../css/cards.css">
        <link rel="stylesheet" href="../css/recipestyle.css">
        <link rel="stylesheet" href="../css/pagefooter.css">
        <link rel="stylesheet" href="../css/rating.css">
        <link rel="stylesheet" href="../css/separator.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <!-- AUTOCOMPLETE SEARCH --> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    </head>
    <body>

        <?php session_start(); 
        if($_SESSION['loggedIn'] == false) {
            header("Location: ../redirect.html");
            exit;
          }
            $query = "SELECT * FROM utenti WHERE username=$1";
            $result = pg_query_params($dbconn, $query, array($_SESSION['username']));
            while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
                $username = $line['username'];
                $idpic = $line['idpic'];
                $email = $line['email'];
                $ricette = $line['ricette'];
                $recensioni = $line['recensioni'];
                $hasImage = $line['picture'];
                if($hasImage) {
                    $parsedUsername = str_replace(array(" ", "'"), "", $username);
                    $imagePath = "../users_pictures/" . $idpic . "profile" . ".jpeg";
                }
                else {
                    $imagePath = "../icons/generic_profile_picture.png";
                }
            }
        ?>

        <!-- GET RECIPES FOR SUGGESTIONS --> 
        <?php
            $query = "SELECT titolo FROM ricette";
            $result = pg_query($dbconn, $query);
            $ricette_arr = array();
            while($row = pg_fetch_assoc($result)) {
                $ricette_arr[] = $row['titolo'];
            }
            $ricette_json = json_encode($ricette_arr);
        ?>

        <!-- MODAL DIALOG CONTACT US-->
        <div id="contattaci" class="modal fade" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">    
                          <h5 class="modal-title" id="exampleModalLabel" >About ForkMates.com </h5>                    
                            <button class="btn-close" data-dismiss="modal"></button>
                          </div>
                          <div class="modal-body">
                            <p class="modal-interface">
                            This website was created by Pietro Colaguori and Claudio Cambone for the course "Languages and Technologies for the Web" at 
                            "La Sapienza" University of Rome. The purpose of the website is to enable its users to quickly and easily browse through
                            various recipes, to add their own recipes and to get every day new suggestions about what to eat!
                            If you want you can contact us to report a bug or make a donation! </p>    
                            <p class="modal-interface" for="donation">Make a donation! (1$ minimum)</p>
                            <input min="1" max="100" type="number" id="donation" class="donation" value="10">
                            <input type="submit" class="button4" value="Make a donation!"> <br> <br>
                            </div>
                            <p class="modal-interface">Report a bug!</p>
                            <textarea name="Report" class="textmodal" id="report" rows="3"> </textarea>
                            <div class="modal-footer">
                            <button class="button5" data-dismiss="modal">Close</button>
                            <input type="submit" class="button4" value="Confirm Review">
                          </div>
                        </div>
                      </div>
                    </div>

<!-- MODAL DIALOG SETTINGS TO MODIFY USERNAME -->
<div class="modal fade" id="changeuser" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Change Username</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form method="POST"action="./changeusername.php">
          <p> Your Actual Username: </p>
          <input class="modal-interface" name="actualname" value="<?php echo"$username"; ?>" readonly> 
          <p class="modal-interface">Your new Username:
          <input type="text" class="modal-interface" id="name" name="newname" required>
        </div>
        <div class="modal-footer">
          <input type="submit" class="button4" value="Confirm Changes?">
          <button class="button5" data-dismiss="modal">Close</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- TO-DO MODAL DIALOG SETTINGS TO MODIFY PROFILE PICTURE -->
<div class="modal fade" id="changepropic" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Modify Profile Picture</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form method="POST" action="./changepropic.php" enctype="multipart/form-data">
          <p class = "modal-interface"> Your Actual Profile Picture: </p>
          <img element id = "profile-icon" src="<?php echo $imagePath;?>">
          <p class="modal-interface">Your new Profile Picture:
          <input type="file" class="modal-interface" id="recipePicture" name="inputPic0">
        </div>
        <div class="modal-footer">
          <input type="submit" class="button4" value="Confirm Changes?">
          <button class="button5" data-dismiss="modal">Close</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- TO-DO MODAL DIALOG SETTINGS TO DELETE PROFILE PICTURE -->
<div class="modal fade" id="deleteacc" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title2">DELETE ACCOUNT</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form method="POST" action="./deleteacc.php">
          <p> Do you want to delete also the Recipes and Reviews?: </p>
          <select name="selezione" class="modal-interface2">
          <option  name="delacc" value="1" selected>Delete just the Account </option>
            <option  name="delreci" value="2">Delete Account and Recipes </option>
            <option  name="delrev" value="3">Delete Account and Reviews </option>
            <option  name="delall" value="4" >Delete Everything </option>
          </select>
          <p class="modal-interface" style="color: red;"><br><strong> Are you sure you want to Delete your account? This action is irriversible. </strong>
        </div>
          <input type="submit" class="buttondel" value="Delete account">
          </form>
         <br>
        </div>
      </div>
    </div>
  </div>
</div>





        <!-- NAVIGATION BAR -->
      <?php
        $id = $_SESSION['username'];
        echo "
        <div class='topnav'>
          <img element id = 'logo' src='../icons/cooking.png'/> 
          <a class=\"active\" href=\"../Homepage.php\">ForkMates</a>
          <a href='../add_recipe/add_recipe.html'>Add a recipe</a>
          <a href='../profile/profile.php?param=".$id."'>Your Profile</a>
          <a href=\"#\" data-toggle=\"modal\" data-target=\"#contattaci\">Contact us</a>
          <a href='../logout.php'>Logout</a>
          <div class=\"search-container\">
            <form method=\"POST\"action=\"../ricerca_ricetta.php\">
              <input id=\"searchbar\" type=\"text\" placeholder=\"Search a Recipe!\" name=\"search\" size=\"50\" autocomplete=\"off\">
              <button type=\"button\" class='btn btn-light'>Search</button>
            </form>
          </div>
        </div>";
      ?>
        <!-- SET AUTOCOMPLETE FOR SEARCH --> 
        <script>
            $(document).ready(function () {
                $("#searchbar").autocomplete({
                source: <?php echo $ricette_json; ?>
                });
            });
        </script>


        <!-- PROFILE -->
        <!-- PROFILE HEADER SECTION -->
        <?php
                $id = $_SESSION['username'];
        ?>
      <div class="container">
        <div class="row"> 
            <div class="col-sm-3">
                <img element id = "profile-icon" src="<?php echo $imagePath;?>">
            </div>
            <div class="col-sm-3">
                <p id="profile-name"><?php echo $username ?></p>
            </div>
            <div class="col-sm-3">
              <div class="profile-stat">
                  <ul id="profile_stats">
                      <li><span class="public_email"> <?php echo $email; ?> </span></li>
                      <li><span class="n_published"><?php echo $ricette; ?> Recipes Published</span></li>
                      <li><span class="n_reviewed"><?php echo $recensioni; ?> Recipes Reviewed</span></li>
                  </ul>
              </div>
            </div>
        </div>
      <div class="row">
        <div class="col-sm-2">
            <div class="dropdown">
            <!-- The trigger element -->
              <div class="dropdown__trigger">Settings</div>
              <!-- The content -->
              <div class="dropdown__content">
              <button class='button6' data-target='#changeuser' data-toggle='modal' onclick='#' name='Changeus'>Change Username</button>
              <button class='button6' data-target='#changepropic' data-toggle='modal' onclick='#' name='Changpp'>Change Profile Picture</button>
              <button class='button6' data-target='#deleteacc' data-toggle='modal' onclick='#' name='Changeus'>Delete Account</button>
            </div>
        </div>
      </div>
    </div>
      <p class="centered">Here are all your Recipes! </p> 
      <hr>
        <!-- END OF PROFILE HEADER SECTION -->

        <!-- PROFILE BODY SECTION -->


        <!-- CARDS VISUALIZATION -->
        <div class="container">
          <div class="row">
            <?php
                $id = $_GET['param'];
                $query = "SELECT * FROM ricette WHERE utente='$id'";
                $result = pg_query_params($dbconn, $query, []);
                while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
                $title = $line["titolo"];
                $utente = $line['utente'];
                $difficulty = $line["difficulty"];
                $prep_time = $line["prep_time"];
                $people = $line["people"];
                $cooking = $line["cooking_time"];
                $hasImage = $line['image'];
                if($hasImage) {
                  $parsedTitle = str_replace(array(" ", "'"), "", $title);
                  $imagePath = './recipes_pictures/' . $parsedTitle . $utente . '.jpeg';
                }
                else {
                  $imagePath = './icons/ricetta.jpeg';
                }
            // variabile hasImage per sapere a quale path fare riferimento TO-DO
              echo '
                <div class="col-sm-3">
                  <div id="card-container">
                    <div id="card-title">'.$title.'</div>
                      <a href="../recipe.php?param='.$title.'">
                        <img element id ="recipe-image" src=../'.$imagePath.'>
                      </a>
                      <div id="details">
                        <span class="detail-value">
                        <img element id = "icon" src="../icons/chef.png"/> 
                        Difficulty: '.$difficulty.'
                        </span>
                        <span class="detail-value">
                          <img element id = "icon" src="../icons/rolling-pin.png"/> 
                          Prep Time: '.$prep_time.'
                        </span>
                        <span class="detail-value"> 
                          <img element id = "icon" src="../icons/cooking.png"/> 
                          Cooking: '.$cooking.'
                        </span>
                        <span class="detail-value">
                          <img element id = "icon" src="../icons/plate.png"/> 
                          Recipe for: '.$people.'
                        </span>
                        <span class="detail-value">
                          <div class="separator">
                            <div class="separator__content">
                            </div>
                            <div class="separator__separator">
                            </div>
                            <div class="rating">
                              <button class="rating__star">☆</button>
                              <button class="rating__star">☆</button>
                              <button class="rating__star">☆</button>
                              <button class="rating__star">☆</button>
                              <button class="rating__star">★</button>
                              </div>
                            </div>
                        </span>
                      </div>  
                    </div>
                  </div>';
                }
              ?>
            </div>
          </div> 
        </div>
        <!-- END OF CARDS VISUALIZATION -->
        <!-- END OF PROFILE BODY SECTION -->
        <!-- END OF PROFILE SECTION -->

    <!-- RETRIEVE REVIEWS --> 
    <?php
        
    ?>


<!-- Site footer -->
<footer class="site-footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <h6>About</h6>
        <p class="text-justify">ForkMates is a univeristy project were peapole can upload their own recipe, review and read other recipe. This is a FREE and NO PROFIT project, nobody earned money during the production</p>
      </div>

      <div class="col-xs-6 col-md-3">
        <h6>Used languages</h6>
        <ul class="footer-links">
          <li>HTML</li>
          <li>PHP</li>
          <li>JAVASCRIPT</li>
          <li>POSTGRESQL</li>
          <li>UX DESIGN</li>
        </ul>
      </div>

      <div class="col-xs-6 col-md-3">
        <h6>Quick links</h6>
        <ul class="footer-links">
          <li><a href="">About</a></li>
          <li><a href="">Contacts</a></li>
          <li><a href="">Contributes</a></li>
          <li><a href="">Privacy policy</a></li>
        </ul>
      </div>
    </div>
    <hr>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-sm-6 col-xs-12">
        <p class="copyright-text">Copyright &copy; 2023 All Rights Reserved by 
     <a href="#">CC</a> and <a href="#">PC </a>
        </p>
      </div>

      <div class="col-md-4 col-sm-6 col-xs-12">
        <ul class="social-icons">
          <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
          <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>   
        </ul>
      </div>
    </div>
  </div>
</footer>
</body>
</html>