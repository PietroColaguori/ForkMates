<?php
    if($_SERVER['REQUEST_METHOD'] != 'POST') {
        header("Location: /profile/profile.php");        
    }
    include '../connectionDB.php';

    session_start();
    
    $idPic = $_SESSION['idpic'];
    if(isset($_FILES["inputPic0"]) && $_FILES["inputPic0"]["error"] == 0) {
        $targetdir = '../users_pictures/';
        $targetfile = "$targetdir" . "$idPic" . "profile" .  ".jpeg";
        move_uploaded_file($_FILES["inputPic0"]["tmp_name"], $targetfile);
        header("Location: ../login/login.html");
    }
    else {
        echo "<script> alert(\"Error: Invalid picture. Try again.\"); </script>";
    }

    pg_close($dbconn);
?>